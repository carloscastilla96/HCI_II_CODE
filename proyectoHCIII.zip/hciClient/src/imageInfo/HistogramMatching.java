package imageInfo;

import com.jogamp.nativewindow.util.PixelFormat;

import gc.L;
import processing.core.PApplet;
import processing.core.PImage;
import root.client.Main;

public class HistogramMatching {
	static PApplet app = Main.getApp();

}
