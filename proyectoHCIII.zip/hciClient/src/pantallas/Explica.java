package pantallas;

import setup.Pantalla;

public class Explica extends Pantalla {

	@Override
	public void iniciar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pintar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void finalizar() {
		// TODO Auto-generated method stub

	}

}
