package setup;

public interface Seguible {

}
